<div class="space-y-6">
    <div class="flex items-center justify-between gap-6">
        @if ($enrollment->rsbsa_reference_number)
        <div class="flex-1">
            <div class="inline-block px-4 py-2 bg-emerald-50 border border-emerald-200 rounded-lg">
                <span class="text-xs text-emerald-700 font-medium">RSBSA Reference Number</span>
                <div class="text-lg font-bold text-emerald-900 mt-1">{{ $enrollment->rsbsa_reference_number }}</div>
            </div>
        </div>
        @endif
        @if ($enrollment->photo_path)
        <div class="flex-shrink-0 flex justify-end">
            <img src="{{ Storage::disk('public')->url($enrollment->photo_path) }}" alt="2x2 Photo" class="w-24 h-24 object-cover rounded border border-emerald-900/10 shadow-sm">
        </div>
        @endif
    </div>
    <!-- Personal Info -->
    <section>
        <div class="h-1 w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-sky-500 rounded"></div>
        <h4 class="mt-3 font-semibold text-emerald-900">Personal Information</h4>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm mt-2">
            <div><span class="text-emerald-700">Name:</span> {{ $enrollment->surname }}, {{ $enrollment->first_name }}</div>
            <div><span class="text-emerald-700">Sex:</span> {{ ucfirst($enrollment->sex) }}</div>
            <div><span class="text-emerald-700">DOB:</span> {{ $enrollment->date_of_birth?->format('Y-m-d') }}</div>
            <div class="md:col-span-3"><span class="text-emerald-700">Place of Birth:</span> {{ $enrollment->place_of_birth }}</div>
        </div>
    </section>

    <!-- Address -->
    <section>
        <div class="h-1 w-full bg-gradient-to-r from-sky-500 via-indigo-500 to-fuchsia-500 rounded"></div>
        <h4 class="mt-3 font-semibold text-emerald-900">Address</h4>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm mt-2">
            <div class="md:col-span-2"><span class="text-emerald-700">Street:</span> {{ $enrollment->address_house_lot }} {{ $enrollment->address_street }}</div>
            <div><span class="text-emerald-700">Barangay:</span> {{ $enrollment->address_barangay }}</div>
            <div><span class="text-emerald-700">City/Municipality:</span> {{ $enrollment->address_municipality_city }}</div>
            <div><span class="text-emerald-700">Province:</span> {{ $enrollment->address_province }}</div>
            <div><span class="text-emerald-700">Region:</span> {{ $enrollment->address_region }}</div>
        </div>
    </section>

    <!-- Farm Profile -->
    <section>
        <div class="h-1 w-full bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded"></div>
        <h4 class="mt-3 font-semibold text-emerald-900">Farm Profile</h4>
        <div class="text-sm mt-2">
            <div><span class="text-emerald-700">Livelihood:</span> {{ ucfirst(str_replace('_',' ', $enrollment->main_livelihood)) }}</div>
        </div>
        @foreach($enrollment->farmParcels as $parcel)
        <div class="mt-3 p-3 rounded border">
            <div class="font-medium text-emerald-900">Parcel #{{ $loop->iteration }}</div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm mt-2">
                <div><span class="text-emerald-700">Barangay:</span> {{ $parcel->barangay }}</div>
                <div><span class="text-emerald-700">Municipality:</span> {{ $parcel->municipality }}</div>
                <div><span class="text-emerald-700">Total Area (ha):</span> {{ $parcel->total_farm_area_ha }}</div>
                <div class="md:col-span-3"><span class="text-emerald-700">Ownership:</span> {{ ucfirst(str_replace('_',' ',$parcel->ownership_type)) }} {{ $parcel->land_owner_name ? '• '.$parcel->land_owner_name : '' }}</div>
            </div>
            @if($parcel->items->count())
            <div class="mt-3">
                <div class="text-emerald-900 font-medium mb-1">Items</div>
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead class="bg-emerald-50/70 text-emerald-900">
                            <tr>
                                <th class="px-3 py-2 text-left">Kind</th>
                                <th class="px-3 py-2 text-left">Name</th>
                                <th class="px-3 py-2 text-left">Size (ha)</th>
                                <th class="px-3 py-2 text-left"># Head</th>
                                <th class="px-3 py-2 text-left">Farm Type</th>
                                <th class="px-3 py-2 text-left">Organic</th>
                                <th class="px-3 py-2 text-left">Remarks</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            @foreach($parcel->items as $it)
                            <tr>
                                <td class="px-3 py-2">{{ ucfirst($it->kind) }}</td>
                                <td class="px-3 py-2">{{ $it->name }}</td>
                                <td class="px-3 py-2">{{ $it->size_ha }}</td>
                                <td class="px-3 py-2">{{ $it->num_of_head }}</td>
                                <td class="px-3 py-2">{{ $it->farm_type }}</td>
                                <td class="px-3 py-2">{{ $it->is_organic_practitioner ? 'Yes' : 'No' }}</td>
                                <td class="px-3 py-2">{{ $it->remarks }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            @endif
        </div>
        @endforeach
    </section>
</div>